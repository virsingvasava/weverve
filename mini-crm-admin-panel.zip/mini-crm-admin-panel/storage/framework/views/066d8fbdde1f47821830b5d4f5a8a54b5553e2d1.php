<?php $__env->startSection('title', 'Users'); ?>
<?php $__env->startSection('content'); ?>
  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Users</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
          <li class="breadcrumb-item">List of</li>
          <li class="breadcrumb-item active">Users</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-12">
          <div class="card recent-sales overflow-auto">

            <div class="filter" style="display:none">
              <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
              <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                <li class="dropdown-header text-start">
                  <h6>Filter</h6>
                </li>

                <li><a class="dropdown-item" href="#">Today</a></li>
                <li><a class="dropdown-item" href="#">This Month</a></li>
                <li><a class="dropdown-item" href="#">This Year</a></li>
              </ul>
            </div>

            <div class="card-body">
              <h5 class="card-title">List of <span>| Users</span></h5>

              <table class="table table-borderless datatable">
                <thead>
                  <tr>
                  

                    <th>Sr. No.</th>
                    <th>City Name</th>
                    <th>Status</th>
                    <th>Action</th>

                  </tr>
                </thead>
                <tbody>
              
                  <?php if(!empty($userArr) && count($userArr) > 0): ?>
                  <?php $__currentLoopData = $userArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td>#<?php echo e($key+1); ?></td>
                      <td><?php echo e(ucfirst($user->name)); ?></td>
                      <td>
                          <?php if($user->status == 1): ?>
                          <!-- <span style="color:green;">Active</span> -->
                          <span class="badge bg-success">Active</span>
                          <?php else: ?>
                          <!-- <span style="color:red;">InActive</span> -->
                          <span class="badge bg-warning">Pending</span>
                          <?php endif; ?>
                      </td>
                      <td class="text-center">
                          </a>
                          <a href="<?php echo e(route('admin.users.edit',$user->id)); ?>" class="btn icon_loader btn-sm btn-primary"><i class="fa fa-pen">Edit</i>
                          </a>
                          <a href="javascript:void(0)" class="btn btn-sm btn-danger delete_button" data-id="<?php echo e($user->id); ?>"><i class="fa fa-trash">Delete</i>
                          </a>
                      </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
              <tr>
                  <td colspan="10">No Users Found.</td>
              </tr>
              <?php endif; ?>

                </tbody>
              </table>

            </div>

          </div>
        </div>
      </div>
    </section>
  </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/laravel7/resources/views/admin/users/index.blade.php ENDPATH**/ ?>