<?php $__env->startSection('title', 'Employees'); ?>
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Users</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                    <li class="breadcrumb-item">List of</li>
                    <li class="breadcrumb-item active">Employees</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section">
            <div class="row">
                <div class="col-12 mt-3 mb-4">
                    <div class="form-group">
                        <div class="col p-0">
                            <a href="<?php echo e(route('admin.employee.create')); ?>" class="btn btn-primary btn-sm"
                                data-repeater-create="" type="button">
                                <i class="bx bx-plus"></i>
                                <span class="invoice-repeat-btn">Add New</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card recent-sales overflow-auto">
                        <div class="filter" style="display:none">
                            <a class="icon" href="#" data-bs-toggle="dropdown"><i class="bi bi-three-dots"></i></a>
                            <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow">
                                <li class="dropdown-header text-start">
                                    <h6>Filter</h6>
                                </li>
                                <li><a class="dropdown-item" href="#">Today</a></li>
                                <li><a class="dropdown-item" href="#">This Month</a></li>
                                <li><a class="dropdown-item" href="#">This Year</a></li>
                            </ul>
                        </div>
                        <div class="card-body">
                            <h5 class="card-title">List of <span>| Users</span></h5>
                            <table class="table table-borderless datatable">
                                <thead>
                                    <tr>
                                        <th>Sr. No.</th>
                                        <th>First Name</th>
                                        <th>Last Name</th>
                                        <th>Email</th>
                                        <th>Phone number</th>
                                        <th>Company Name</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(!empty($employeeArr) && count($employeeArr) > 0): ?>
                                        <?php $__currentLoopData = $employeeArr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $companyName = App\Models\Company::where('id',$value->company_id)->first();
                                            ?>
                                            <tr>
                                                <td>#<?php echo e($key + 1); ?></td>
                                                <td><?php echo e(ucfirst($value->first_name)); ?></td>
                                                <td><?php echo e(ucfirst($value->last_name)); ?></td>
                                                <td><?php echo e($value->email); ?></td>
                                                <td><?php echo e($value->phone_number); ?></td>
                                                <td>
                                                    <?php if(!empty($companyName->name)): ?>
                                                        <?php echo e($companyName->name); ?>

                                                    <?php else: ?>
                                                        <span>--</span>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <div class="d-flex justify-content-between py-50">
                                                        <div class="custom-control custom-switch custom-switch-glow">
                                                            <input type="checkbox" data-id="<?php echo e($value->id); ?>"
                                                                name="status" class="js-switch-employee"
                                                                <?php echo e($value->status == 1 ? 'checked' : ''); ?>>
                                                        </div>
                                                    </div>
                                                </td>
                                                <td class="text-center">

                                                    <a href="<?php echo e(route('admin.employee.view',$value->id)); ?>" class="btn icon_loader btn-sm btn-info"><i class="ri-eye-fill"></i>
                                                    </a>
                                                    <a href="<?php echo e(route('admin.employee.edit',$value->id)); ?>" class="btn icon_loader btn-sm btn-primary"><i class="ri-edit-box-fill"></i>
                                                    </a>
                                                    <a href="javascript:void(0)" class="btn btn-sm btn-danger delete_button_employee" data-id="<?php echo e($value->id); ?>"><i class="ri-delete-bin-6-fill"></i></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                        <tr>
                                            <td colspan="10">No Employee Found.</td>
                                        </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
    <!-- Popup modal for Delete start -->
    <div class="modal fade" id="employeeDeleteModel" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Are You sure ?</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    Are you sure to Delete Employee?
                </div>
                <form method="post" action="<?php echo e(route('admin.employee.delete')); ?>" id="form_delete">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" class="page_id">
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-danger form_submit btn_loader">Delete</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- delete modal Modal start-->

    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/mini-crm-admin-panel/resources/views/admin/employee/index.blade.php ENDPATH**/ ?>