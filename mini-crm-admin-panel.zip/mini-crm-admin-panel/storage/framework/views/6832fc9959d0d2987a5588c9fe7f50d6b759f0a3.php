<?php $__env->startSection('title', 'Employees - View'); ?>
<?php $__env->startSection('content'); ?>
    <main id="main" class="main">
        <div class="pagetitle">
            <h1>Employees</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.dashboard')); ?>">Home</a></li>
                    <li class="breadcrumb-item">View</li>
                    <li class="breadcrumb-item active"><a href="<?php echo e(route('admin.employee.index')); ?>">Employees List</a></li>
                </ol>
            </nav>
        </div>
        <section class="section">
            <div class="row">
                <div class="col-12 mt-3 mb-4">
                    <div class="form-group">
                        <div class="col p-0">
                            <a href="<?php echo e(route('admin.employee.index')); ?>" class="btn btn-primary btn-sm"
                                data-repeater-create="" type="button">
                                <span><i class="ri-arrow-left-circle-fill"></i></span>
                                <span class="invoice-repeat-btn">Back</span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card recent-sales overflow-auto">
                        <div class="card-body">
                            <h5 class="card-title">View <span>| Employee Details</span></h5>
                            <table class="table table-bordered table-striped">
                                <?php
                                    $companyName = App\Models\Company::where('id', $employee_view->company_id)->first();
                                ?>
                                <tbody>
                                    <tr>
                                        <th>First Name</th>
                                        <td><?php echo e($employee_view->first_name); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Last Name</th>
                                        <td><?php echo e($employee_view->last_name); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Email</th>
                                        <td><?php echo e($employee_view->email); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Phone Number</th>
                                        <td><?php echo e($employee_view->phone_number); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Company Name</th>
                                        <td>
                                            <?php if(!empty($companyName->name)): ?>
                                                <?php echo e($companyName->name); ?>

                                            <?php else: ?>
                                                <span>--</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Status</th>
                                        <td>
                                            <?php if($employee_view->status == 1): ?>
                                                <span style="color:green;">Active</span>
                                            <?php else: ?>
                                                <span style="color:red;">InActive</span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/mini-crm-admin-panel/resources/views/admin/employee/view.blade.php ENDPATH**/ ?>