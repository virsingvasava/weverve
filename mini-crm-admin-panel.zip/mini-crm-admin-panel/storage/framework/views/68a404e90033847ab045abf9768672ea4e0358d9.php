<?php echo $__env->make('layouts.login_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('layouts.login_footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH /opt/lampp/htdocs/Admin_panel/resources/views/layouts/login_app.blade.php ENDPATH**/ ?>