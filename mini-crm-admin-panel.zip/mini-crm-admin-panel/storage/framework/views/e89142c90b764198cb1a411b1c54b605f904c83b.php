<aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

        <li class="nav-item ">
            <a class="nav-link <?php echo e(request()->is('admin/dashboard*') ? '' : 'collapsed'); ?>"
                href="<?php echo e(route('admin.dashboard')); ?>">
                <i class="bi bi-grid"></i>
                <span>Dashboard</span>
            </a>
        </li>

        <li class="nav-heading">Master</li>

        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('admin/company*') ? '' : 'collapsed'); ?>"
                href="<?php echo e(route('admin.company.index')); ?>">
                <i class="ri-list-check"></i>
                <span>Companies</span>
            </a>
        </li>

        <li class="nav-item">
            <a class="nav-link <?php echo e(request()->is('admin/employee*') ? '' : 'collapsed'); ?>"
                href="<?php echo e(route('admin.employee.index')); ?>">
                <i class="ri-admin-fill"></i>
                <span>Employees</span>
            </a>
        </li>

        <li class="nav-heading">Settings</li>
        <li class="nav-item">
            <a class="nav-link collapsed" data-bs-target="#components-nav" data-bs-toggle="collapse" href="#">
                <i class="ri-list-settings-fill"></i><span>Admin Settings</span>
            </a>
            <ul id="components-nav" class="nav-content collapse " data-bs-parent="#sidebar-nav">
                <li>
                    <a class="nav-link <?php echo e(request()->is('admin/profile*') ? '' : 'collapsed'); ?>"
                        href="<?php echo e(route('admin.profile.index')); ?>">
                        <i class="bi bi-person"></i>
                        <span>Profile</span>
                    </a>
                </li>
            </ul>
        </li>
    </ul>
</aside>
<?php /**PATH /opt/lampp/htdocs/mini-crm-admin-panel/resources/views/layouts/admin_sidebar.blade.php ENDPATH**/ ?>